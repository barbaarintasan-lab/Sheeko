import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (simple auth for Sheeko)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password"),
  name: text("name").notNull(),
  picture: text("picture"),
  phone: text("phone"),
  isAdmin: boolean("is_admin").notNull().default(false),
  canHostSheeko: boolean("can_host_sheeko").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastLoginAt: timestamp("last_login_at"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLoginAt: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Voice Rooms table (Spaces where users can talk)
export const voiceRooms = pgTable("voice_rooms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  hostId: varchar("host_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("scheduled"), // scheduled, live, ended
  scheduledAt: timestamp("scheduled_at"),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  maxSpeakers: integer("max_speakers").notNull().default(5),
  isRecorded: boolean("is_recorded").notNull().default(false),
  recordingUrl: text("recording_url"),
  pinnedMessageId: varchar("pinned_message_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertVoiceRoomSchema = createInsertSchema(voiceRooms).omit({ 
  id: true, 
  createdAt: true, 
  startedAt: true, 
  endedAt: true, 
  recordingUrl: true 
});
export type InsertVoiceRoom = z.infer<typeof insertVoiceRoomSchema>;
export type VoiceRoom = typeof voiceRooms.$inferSelect;

// Voice Room Participants table
export const voiceParticipants = pgTable("voice_participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").notNull().references(() => voiceRooms.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  role: text("role").notNull().default("listener"), // listener, speaker, co-host
  isMuted: boolean("is_muted").notNull().default(true),
  isHidden: boolean("is_hidden").notNull().default(false),
  handRaised: boolean("hand_raised").notNull().default(false),
  handRaisedAt: timestamp("hand_raised_at"),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
  leftAt: timestamp("left_at"),
});

export const insertVoiceParticipantSchema = createInsertSchema(voiceParticipants).omit({ 
  id: true, 
  joinedAt: true, 
  leftAt: true, 
  handRaisedAt: true 
});
export type InsertVoiceParticipant = z.infer<typeof insertVoiceParticipantSchema>;
export type VoiceParticipant = typeof voiceParticipants.$inferSelect;

// Voice Room Messages table (Live chat)
export const voiceRoomMessages = pgTable("voice_room_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").notNull().references(() => voiceRooms.id, { onDelete: "cascade" }),
  userId: varchar("user_id").references(() => users.id, { onDelete: "set null" }),
  guestId: varchar("guest_id"),
  displayName: varchar("display_name").notNull(),
  message: text("message").notNull(),
  isHidden: boolean("is_hidden").notNull().default(false),
  aiModerated: boolean("ai_moderated").notNull().default(false),
  moderationReason: text("moderation_reason"),
  moderationScore: real("moderation_score"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertVoiceRoomMessageSchema = createInsertSchema(voiceRoomMessages).omit({ 
  id: true, 
  createdAt: true 
});
export type InsertVoiceRoomMessage = z.infer<typeof insertVoiceRoomMessageSchema>;
export type VoiceRoomMessage = typeof voiceRoomMessages.$inferSelect;

// Voice Room RSVPs table
export const voiceRoomRsvps = pgTable("voice_room_rsvps", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").notNull().references(() => voiceRooms.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertVoiceRoomRsvpSchema = createInsertSchema(voiceRoomRsvps).omit({ 
  id: true, 
  createdAt: true 
});
export type InsertVoiceRoomRsvp = z.infer<typeof insertVoiceRoomRsvpSchema>;
export type VoiceRoomRsvp = typeof voiceRoomRsvps.$inferSelect;

// Voice Recordings table
export const voiceRecordings = pgTable("voice_recordings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").references(() => voiceRooms.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  description: text("description"),
  hostId: varchar("host_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  objectPath: text("object_path"),
  duration: integer("duration"),
  fileSize: integer("file_size"),
  isPublished: boolean("is_published").notNull().default(false),
  participantCount: integer("participant_count"),
  recordedAt: timestamp("recorded_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertVoiceRecordingSchema = createInsertSchema(voiceRecordings).omit({ 
  id: true, 
  createdAt: true 
});
export type InsertVoiceRecording = z.infer<typeof insertVoiceRecordingSchema>;
export type VoiceRecording = typeof voiceRecordings.$inferSelect;

// Voice Room Bans table
export const voiceRoomBans = pgTable("voice_room_bans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").notNull().references(() => voiceRooms.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  bannedById: varchar("banned_by_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  reason: text("reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertVoiceRoomBanSchema = createInsertSchema(voiceRoomBans).omit({ 
  id: true, 
  createdAt: true 
});
export type InsertVoiceRoomBan = z.infer<typeof insertVoiceRoomBanSchema>;
export type VoiceRoomBan = typeof voiceRoomBans.$inferSelect;

// Host Followers table
export const hostFollows = pgTable("host_follows", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  followerId: varchar("follower_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  hostId: varchar("host_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertHostFollowSchema = createInsertSchema(hostFollows).omit({ 
  id: true, 
  createdAt: true 
});
export type InsertHostFollow = z.infer<typeof insertHostFollowSchema>;
export type HostFollow = typeof hostFollows.$inferSelect;
